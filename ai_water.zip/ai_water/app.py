from flask import Flask, render_template, request, jsonify
import os
import cv2
import numpy as np
import joblib

app = Flask(__name__)

# Auto-load model (no manual editing)
MODEL_PATH = "rgb_model.pkl"
model = joblib.load(MODEL_PATH) if os.path.exists(MODEL_PATH) else None

manual_data_records = []

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/data_prediction')
def data_prediction():
    return render_template('data_prediction.html', records=manual_data_records)

@app.route('/predict', methods=['POST'])
def predict():
    try:
        file = request.files.get('file')
        if not file or file.filename == '':
            return jsonify({'success': False, 'message': 'No file uploaded'})

        filepath = os.path.join('static', file.filename)
        file.save(filepath)

        img = cv2.imread(filepath)
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        avg_color = img_rgb.mean(axis=(0, 1))
        std_color = img_rgb.std(axis=(0, 1))
        texture = np.var(gray)

        features = np.array([[avg_color[0], avg_color[1], avg_color[2],
                              std_color[0], std_color[1], std_color[2],
                              texture]])

        if model:
            pred_idx = model.predict(features)[0]
            proba = model.predict_proba(features)[0]
            confidence = round(np.max(proba), 2)
            label_map = {0: 'Good', 1: 'Moderate', 2: 'Poor'}
            pred_label = label_map[pred_idx]
        else:
            pred_label = "Model not trained"
            confidence = 0

        return jsonify({
            'success': True,
            'predicted_label': pred_label,
            'confidence': confidence,
            'rgb_values': {'r': int(avg_color[0]), 'g': int(avg_color[1]), 'b': int(avg_color[2])}
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/predict_data', methods=['POST'])
def predict_data():
    try:
        ph = float(request.form['ph'])
        do = float(request.form['do'])
        bod = float(request.form['bod'])
        cond = float(request.form['conductivity'])
        turb = float(request.form['turbidity'])
        nitrate = float(request.form['nitrate'])

        if ph >= 6.5 and ph <= 8.5 and do > 5 and bod < 3:
            prediction = "Good"
        elif bod < 6:
            prediction = "Moderate"
        else:
            prediction = "Poor"

        record = {
            "pH": ph, "DO": do, "BOD": bod,
            "Conductivity": cond, "Turbidity": turb,
            "Nitrate": nitrate, "Result": prediction
        }
        manual_data_records.append(record)
        return render_template("data_prediction.html", records=manual_data_records, message=f"Prediction: {prediction}")
    except Exception as e:
        return render_template("data_prediction.html", records=manual_data_records, message=f"Error: {e}")

if __name__ == '__main__':
    app.run(debug=True)
