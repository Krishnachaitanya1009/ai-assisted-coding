import os
import cv2
import numpy as np
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

DATA_DIR = "dataset"
MODEL_FILENAME = "rgb_model.pkl"

def extract_features(image_path):
    img = cv2.imread(image_path)
    if img is None:
        return None
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    avg_color = img_rgb.mean(axis=(0, 1))
    std_color = img_rgb.std(axis=(0, 1))
    texture = np.var(gray)

    return [
        avg_color[0], avg_color[1], avg_color[2],
        std_color[0], std_color[1], std_color[2],
        texture
    ]

def main():
    X, y = [], []
    label_map = {'good': 0, 'moderate': 1, 'poor': 2}

    for label_name, label_id in label_map.items():
        folder = os.path.join(DATA_DIR, label_name)
        if not os.path.isdir(folder):
            continue
        for file in os.listdir(folder):
            if file.lower().endswith(('.jpg', '.jpeg', '.png')):
                path = os.path.join(folder, file)
                features = extract_features(path)
                if features is not None:
                    X.append(features)
                    y.append(label_id)

    X = np.array(X)
    y = np.array(y)
    if len(X) == 0:
        print("No data found. Check dataset folder.")
        return

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    model = RandomForestClassifier(n_estimators=200, random_state=42)
    model.fit(X_train, y_train)

    preds = model.predict(X_test)
    print("\n--- Model Evaluation ---")
    print(classification_report(y_test, preds, target_names=['Good','Moderate','Poor']))

    joblib.dump(model, MODEL_FILENAME)
    print(f"\n✅ Model trained and saved as {MODEL_FILENAME}")

if __name__ == "__main__":
    main()
